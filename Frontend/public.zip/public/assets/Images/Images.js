const lock = "https://res.cloudinary.com/manjindersingh/image/upload/v1743094458/Portfolio/public/Images/nzewkdifekfmj7otzalx.jpg"
const codeTogetherLogo = "https://res.cloudinary.com/manjindersingh/image/upload/v1743094457/Portfolio/public/Images/m558c8gvwf2wwsbobx6s.png"
const typingManiaLogo = "https://res.cloudinary.com/manjindersingh/image/upload/v1743094458/Portfolio/public/Images/n4kzwkfrogdpegnyopji.png"
const jwtLogo = "https://res.cloudinary.com/manjindersingh/image/upload/v1743094458/Portfolio/public/Images/ols4lsutktimctf6optg.png"
const execuConnectLogo = "https://res.cloudinary.com/manjindersingh/image/upload/v1743094457/Portfolio/public/Images/f0fyhcyclacf3qaa0zyn.png"

export {lock, codeTogetherLogo, typingManiaLogo, jwtLogo, execuConnectLogo}