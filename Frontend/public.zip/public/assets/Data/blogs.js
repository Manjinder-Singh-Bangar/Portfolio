import authBlogData from "./auth-blog.md?raw"
import codeTogetherData from "./codeTogetherBlog.md?raw"
import execuConnectData from "./execuConnect-blog.md?raw"
import typingManiaData from "./typing-mania-blog.md?raw"
import jwtBlogData from "./jwt-blog.md?raw"

import myImageSrc from "../Images/myImage.jpg"
import reactAuthThumbnail from "../Images/lock.jpg"
import jwtLogoThumbnail from "../Images/Jwt-logo.png"
import codeTogetherLogo from "../Images/CodeTogetherLogo.png"
import typingManiaThumbnail from "../Images/TypingManiaLogo.png"
import ExecuConnectLogoThumbnail from "../Images/ExecuConnectLogo.png"

const blogs = [
    {
        id: 1,
        headingOfBlog: "How to Set Up Authentication in React: A Step-by-Step Guide",
        author: "Manjinder Singh",
        dateWritten: "March 13, 2025",
        profilePicture: myImageSrc,
        fileName: authBlogData,
        job: "Full stack developer",
        location: "Toronto",
        thumbnail: "https://res.cloudinary.com/manjindersingh/image/upload/v1743094458/Portfolio/public/Images/nzewkdifekfmj7otzalx.jpg"
    },
    {
        id: 2,
        headingOfBlog: "Understanding JSON Web Tokens (JWT): From Basics to Intermediate",
        author: "Manjinder Singh",
        dateWritten: "March 16, 2025",
        profilePicture: myImageSrc,
        fileName: jwtBlogData,
        job: "Full stack developer",
        location: "Toronto",
        thumbnail:"https://res.cloudinary.com/manjindersingh/image/upload/v1743094458/Portfolio/public/Images/ols4lsutktimctf6optg.png"
    },
    {
        id: 3,
        headingOfBlog: "CodeTogether - A Social Platform for Developers",
        author: "Manjinder Singh",
        dateWritten: "March 16, 2025",
        profilePicture: myImageSrc,
        fileName: codeTogetherData,
        job: "Full stack developer",
        location: "Toronto",
        thumbnail: "https://res.cloudinary.com/manjindersingh/image/upload/v1743094457/Portfolio/public/Images/m558c8gvwf2wwsbobx6s.png"
    },
    {
        id: 4,
        headingOfBlog: "Typing Mania - A Fun Typing Speed Test Platform",
        author: "Manjinder Singh",
        dateWritten: "March 16, 2025",
        profilePicture: myImageSrc,
        fileName: typingManiaData,
        job: "Full stack developer",
        location: "Toronto",
        thumbnail: "https://res.cloudinary.com/manjindersingh/image/upload/v1743094458/Portfolio/public/Images/n4kzwkfrogdpegnyopji.png"
    },
    {
        id: 5,
        headingOfBlog: "Executive Networking Platform",
        author: "Manjinder Singh",
        dateWritten: "March 16, 2025",
        profilePicture: myImageSrc,
        fileName: execuConnectData,
        job: "Full stack developer",
        location: "Toronto",
        thumbnail: "https://res.cloudinary.com/manjindersingh/image/upload/v1743094457/Portfolio/public/Images/f0fyhcyclacf3qaa0zyn.png"
    }

]


export {blogs}